local SkillStateEnum = {}

SkillStateEnum.INIT = -1
SkillStateEnum.BEFORE = 0
SkillStateEnum.USE = 1
SkillStateEnum.DAMAGE = 2	
SkillStateEnum.SKILLEND = 3	
SkillStateEnum.SKILLOVER = 4


return SkillStateEnum