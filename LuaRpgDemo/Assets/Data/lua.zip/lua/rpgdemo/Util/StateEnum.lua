local StateEnum = {}

StateEnum.IDLE = "idle"
StateEnum.PATROL = "patrol"
StateEnum.ALERT = "alert"	
StateEnum.FOLLOW = "follow"	
StateEnum.ATTACK = "attack"	
StateEnum.FLEE = "flee"
StateEnum.DEAD = "dead" 	

return StateEnum